export const condiments = [
    {
        name: 'Bun',
        price: '2'
    },
    {
        name: 'Salad',
        price: '6'
    },
    {
        name: 'Cheese slices',
        price: '1'
    },
    {
        name: 'Cutlets',
        price: '5'
    }
];