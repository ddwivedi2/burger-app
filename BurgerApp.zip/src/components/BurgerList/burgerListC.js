export const globalBurgers = [
    {
        name: 'King Mac',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '100'
    },
    {
        name: 'King Mac2',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '200'
    },
    {
        name: 'King Mac3',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '400'
    },
    {
        name: 'King Mac4',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '100'
    },
    {name: 'King Mac5',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '100'},
    {
        name: 'King Mac6',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '100'
    },
    {
        name: 'King Mac7',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '100'
    },
    {
        name: 'King Mac8',
        imageURL: 'https://bit.ly/2RwPt17',
        price: '100'
    },
];